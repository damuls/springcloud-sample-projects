# TwoStepsFromJava-Cloud-Feign

Spring Cloud 示例项目：结合Ribbon和Feign实现声明式服务调用。


Spring Cloud Release Trains: [Dalston.SR1](http://projects.spring.io/spring-cloud/) 